package com.JavaShine.department.websecurityconfig;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;

public class WebsecurityConfig   {

	@Autowired
	private DataSource datasource;

	


}
