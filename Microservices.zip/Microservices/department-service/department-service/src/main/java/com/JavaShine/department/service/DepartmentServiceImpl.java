package com.JavaShine.department.service;

import java.util.List;

import com.JavaShine.department.enitiy.Department;

public interface DepartmentServiceImpl {
	public List<Department> getAll();

}
