package com.JavaShine.department.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.JavaShine.department.enitiy.Department;
import com.JavaShine.department.service.DepartmentService;

@RestController
@RequestMapping("/Department")
public class DepartmentController {

	@Autowired
	private DepartmentService  departmentservice;
	
	@RequestMapping("/getall")
	public List<Department> getall(){
		
	
		return  departmentservice.getAll();
		
		
	}
	

}
