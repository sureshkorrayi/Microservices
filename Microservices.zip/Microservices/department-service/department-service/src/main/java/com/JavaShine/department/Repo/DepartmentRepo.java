package com.JavaShine.department.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.JavaShine.department.enitiy.Department;


@Repository
public interface DepartmentRepo extends  JpaRepository<Department,Long>
{
	
	
	
	
	
}
