package com.JavaShine.department.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.JavaShine.department.Repo.DepartmentRepo;
import com.JavaShine.department.enitiy.Department;

@Service
public class DepartmentService implements DepartmentServiceImpl{
    
	@Autowired
	private DepartmentRepo departmentrepo;

	@Override
	
	public List<Department> getAll() {
	   
		return departmentrepo.findAll();
   
	}
	
	
}
