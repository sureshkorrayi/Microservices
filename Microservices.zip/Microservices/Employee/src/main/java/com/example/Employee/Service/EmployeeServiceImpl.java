package com.example.Employee.Service;

import java.util.List;

import com.example.Employee.Entity.Employee;

public interface EmployeeServiceImpl  {
	
   public List<Employee> getAll();

}
